public class Game {
    public int JumpGame(int[] numbers) {
        int n = numbers.length;
        if( n < 2)
         return 0;   

        int jumps = 0;
        int currentEnd = 0;
        int currentFarthest = 0;

        for (int i = 0; i < n - 1; i++) {
            currentFarthest = Math.max(currentFarthest, i + numbers[i]);

            if (i == currentEnd) {
                jumps++;
                currentEnd = currentFarthest;

                if (currentEnd >= n - 1)
                    break;
            }
        }

        return jumps;



    }
}
