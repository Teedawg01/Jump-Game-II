//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Game game = new Game();

        int[] nums1 = {2, 3, 1, 1, 4};
        System.out.println("Test Case 1: " + game.JumpGame(nums1));

        int[] nums2 = {2, 3, 0, 1, 4};
        System.out.println("Test Case 2: " + game.JumpGame(nums2));

    }
}